/*
 * Copyright (c) 2026, Vlad Mesco
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// Pipeline setup:
// 1. Initialize Media3.Transformer, which has a Listener
// 2. Initialize tts, which has a Listener
// 3. Trigger first processNextChunk
//
// Pipelining:
// o-> processNextChunk
//     isCancelled -> End
//     textChunks
//         None -> End
//         Some -> synthesizeToFile -o
//             o-> onDone
//                 isCancelled -> End
//                 transformer.start -o
//                     o-> onCompleted
//                         -> isCancelled -> End
//                         -> processNextChunk -o
//
// In other words:
//    TTS synthesizes text -> WAV file ->
//    onDone() -> Transformer encodes WAV to m4a ->
//    onCompleted() -> Delete WAV -> (repeat)
//
// Chunk for TTS is determined by Sequence<String>.batchByLength(reasonableChunk)
// using BookTextExtractor as a starting point
//
// In the end, merge all m4a files into consolidated one.
// Then, perhaps populate metadata?


package alzwded.openaudiobookify

import alzwded.openaudiobookify.engine.EdgeTtsEngine

import android.content.Context
import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.accessibility.AccessibilityManager
import android.accessibilityservice.AccessibilityServiceInfo
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.Codec
import java.io.File

private const val TAG = "OAB_AUDIOBOOK_PIPELINE"

@UnstableApi
class AudiobookPipeline(
    private val context: Context,
    private val tts: TextToSpeech,
    private val provider: BookTextProvider,
    private val bookName: String,
    private val outputDirUri: Uri?,
    private val targetBitrate: Int = 48000,
    private val onProgress: (BookStatus, Int) -> Unit = { bookStatus, chunk -> },
    private val onError: (String) -> Unit = {},
    private val onPipelineComplete: () -> Unit
) {
    private val textChunks: Iterator<TextChunk> = provider.extractText().batchByLength(getBatchSize()).iterator()
    private var chunkIndex = 0
    @Volatile private var isCancelled = false

     private val ttsEngine = AndroidTtsEngine(tts)"
    )

    // Keep track of our encoded intermediate m4a chunks
    private val encodedChunkFiles = mutableListOf<File>()

    // lambda to call as continuation, part of the restartable utterance
    // See UtteranceProgressListener.onStop / .handleTtsInterruption
    private var synthesizeCurrentChunk: () -> Int = { ->
        TextToSpeech.ERROR
    }

    private var isTalkbackRunning = false

    // when TalkBack is running, it will interrupt TTS.
    // So use a much smaller chunk size than in sighted mode
    // to reduce the chances of interruption. This is not ideal,
    // as it will probably induce unnatural pauses in sentences,
    // but it is what it is. The alternative might be "it dudn't work"
    private fun getBatchSize(): Int {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val defaultMaxLength = 3900
        if (!am.isEnabled) return defaultMaxLength
        val enabled = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_SPOKEN)
        // If any service provides spoken feedback it's very likely TalkBack (or another screen reader) is active
        if (enabled.isNotEmpty()) {
            // XXX yeh yeh, this is ugly
            isTalkbackRunning = true
            // 5-8s, maybe even more...
            return 200
        } else {
            // as long as we can
            return defaultMaxLength
        }
    }

    /**
     * Creates a Transformer configured for Mono, 48kbps AAC.
     */
    private fun createAudioTransformer(listener: Transformer.Listener): Transformer {
        val defaultEncoderFactory = DefaultEncoderFactory.Builder(context).build()
        
        val customEncoderFactory = object : Codec.EncoderFactory {
            override fun createForAudioEncoding(
                format: androidx.media3.common.Format,
                logSessionId: android.media.metrics.LogSessionId?
            ): Codec {
                val customFormat = format.buildUpon()
                    .setChannelCount(1)
                    .setSampleRate(44100)
                    .setAverageBitrate(targetBitrate)
                    .build()
                return defaultEncoderFactory.createForAudioEncoding(customFormat, logSessionId)
            }

            override fun createForVideoEncoding(
                format: androidx.media3.common.Format,
                logSessionId: android.media.metrics.LogSessionId?
            ): Codec {
                return defaultEncoderFactory.createForVideoEncoding(format, logSessionId)
            }
        }

        return Transformer.Builder(context)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(customEncoderFactory)
            .addListener(listener)
            .build()
    }

    /**
     * Creates a barebones Transformer optimized for transmuxing (passthrough).
     * Media3 will automatically copy compressed audio samples directly without re-encoding
     * because the input chunk formats already match perfectly.
     */
    private fun createPassthroughTransformer(listener: Transformer.Listener): Transformer {
        return Transformer.Builder(context)
            .addListener(listener)
            .build() 
    }

    // Transformer for encoding WAV -> M4A
    private val chunkTransformer: Transformer by lazy {
        createAudioTransformer(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                Log.i(TAG, "Completed $chunkIndex")
                if (isCancelled) return

                val wavFile = getWavFile(chunkIndex)
                if (wavFile.exists()) wavFile.delete()

                val edgeMp3File = getEdgeMp3File(chunkIndex)
                if (edgeMp3File.exists()) edgeMp3File.delete()

                val tempM4a = getTempM4aFile(chunkIndex)
                if (tempM4a.exists()) {
                    encodedChunkFiles.add(tempM4a)
                }

                processNextChunk()
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                Log.e(TAG, "Chunk MediaCodec Error on chunk $chunkIndex: ${exportException.message}")
                cleanup()
                onError(context.getString(R.string.error_mediacodec, chunkIndex))
            }
        })
    }

    fun start() {
        Log.i(TAG, "Starting pipeline")
        setupTtsListener()
        processNextChunk()
    }

    fun cancel() {
        Log.i(TAG, "Canceling pipeline")
        isCancelled = true
        tts.stop()
        chunkTransformer.cancel()
        cleanup()
    }

    private fun processNextChunk() {
        if (isCancelled) return

        if (!textChunks.hasNext()) {
            Log.i(TAG, "No more chunks")
            mergeChunksAndExport()
            return
        }

        Log.i(TAG, "Processing next chunk $chunkIndex")

        chunkIndex++
        val chunk = textChunks.next()
        onProgress(
            BookStatus.SPEAKING,
            ((chunk.progress ?: 0.5f) * 90.0f).toInt()
        )

        val text = chunk.text
        val edgeFile = getEdgeMp3File(chunkIndex)

        if (edgeFile.exists()) edgeFile.delete()

        Log.i(TAG, "Requesting Edge TTS for chunk $chunkIndex")

        edgeTtsEngine.synthesize(
            text = text,
            outputFile = edgeFile,
            onSuccess = { generatedFile ->
                if (isCancelled) return@synthesize

                Handler(context.mainLooper).post {
                    if (!isCancelled) {
                        encodeWavToM4a(
                            generatedFile,
                            getTempM4aFile(chunkIndex)
                        )
                    }
                }
            },
            onError = { message ->
                if (!isCancelled) {
                    Log.e(TAG, "Edge TTS error on chunk $chunkIndex: $message")
                    isCancelled = true
                    cleanup()
                    this@AudiobookPipeline.onError("Edge TTS: $message")
                }
            }
        )
    }

    private fun setupTtsListener() {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                Log.i(TAG, "Starting TTS utterance for $utteranceId")
            }

            override fun onDone(utteranceId: String?) {
                Log.i(TAG, "Finished TTS utterance for $utteranceId")
                if (isCancelled) return
                Handler(context.mainLooper).post {
                    encodeWavToM4a(getWavFile(chunkIndex), getTempM4aFile(chunkIndex))
                }
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                super.onStop(utteranceId, interrupted)
                handleTtsInterruption(utteranceId, interrupted)
            }

            private fun handleErrorOrInterruption(utteranceId: String?, errorCode: Int) {
                Log.w(TAG, "TTS Error on $utteranceId with code: $errorCode")
                
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && isTalkbackRunning) {
                    // Pre-API 29: TalkBack interruptions usually manifest as generic errors.
                    // More specifically, Google TTS would do nothing, and everything would just
                    // freeze up. Honestly, I'd rather bump minSdk to 29 than chase that particular
                    // rabbit down this particular rabbit hole.
                    Log.i(TAG, "API < 29 detected while talkback is running, treating error as an interruption.")
                    handleTtsInterruption(utteranceId, true)
                } else {
                    // API 29+: If we get here, it's a real unrecoverable TTS error, 
                    // NOT an interruption (since interruptions go to onStop).
                    Log.e(TAG, "TTS Error on chunk $chunkIndex: $errorCode")
                    isCancelled = true
                    cleanup()
                    this@AudiobookPipeline.onError(
                        context.getString(
                            R.string.error_tts_exception,
                            "Error code $errorCode"
                        )
                    )
                }
            }

            private fun handleTtsInterruption(utteranceId: String?, interrupted: Boolean) {
                Log.w(TAG, "TTS utterance stopped for $utteranceId, interrupted=$interrupted")
                if (isCancelled) return
                
                // Talkback (or another app) flushed the TTS queue. 
                // We need to retry the *current* chunk (don't increment chunkIndex yet).
                Handler(context.mainLooper).postDelayed({
                    if (isCancelled) return@postDelayed 
                    Log.i(TAG, "Retrying TTS utterance for $utteranceId after interruption")
                    // Nuke the partially written file to ensure a clean header on retry
                    if (interrupted) {
                        // interrupted==false means the utterance was never started, so there should be no file.
                        val wavFile = getWavFile(chunkIndex)
                        if (wavFile.exists()) wavFile.delete()
                    }
                    // retry
                    synthesizeCurrentChunk()
                }, 1500L) // 1.5s backoff gives TalkBack time to finish reading its UI event
            }

            @Deprecated("Deprecated in Java")
            override fun onError(p0: String?) {
                this.onError(p0 ?: "unknown", 0);
            }

            override fun onError(utteranceId: String, errorCode: Int) {
                handleErrorOrInterruption(utteranceId, errorCode)
            }
        })
    }

    private fun encodeWavToM4a(wavFile: File, m4aFile: File) {
        if (isCancelled) return

        Log.i(TAG, "Encoding wav to m4a")
        if (m4aFile.exists()) m4aFile.delete()

        val mediaItem = MediaItem.fromUri(Uri.fromFile(wavFile))
        chunkTransformer.start(mediaItem, m4aFile.absolutePath)
    }

    private fun mergeChunksAndExport() {
        if (encodedChunkFiles.isEmpty()) {
            Log.w(TAG, "mergeChunksAndExport: nothing to do")
            cleanup()
            onPipelineComplete()
            return
        }

        Log.i(TAG, "Merging all chunks")

        val editedMediaItems = encodedChunkFiles.map { file ->
            val mediaItem = MediaItem.fromUri(Uri.fromFile(file))
            EditedMediaItem.Builder(mediaItem).build()
        }

        val sequence = EditedMediaItemSequence.withAudioFrom(editedMediaItems)
        val composition = Composition.Builder(sequence)
            .setTransmuxAudio(true)
            .build()

        val finalTempFile = File(context.cacheDir, "final_merged_audiobook.m4a")
        if (finalTempFile.exists()) finalTempFile.delete()

        onProgress(BookStatus.MERGING, 95);

        val mergeTransformer = createPassthroughTransformer(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                Log.i(TAG, "Final m4a completed")
                if (!isCancelled) {
                    if (writeToOutputDir(finalTempFile)) {
                        cleanup(finalTempFile)
                        onPipelineComplete()
                    } else {
                        cleanup(finalTempFile)
                        onError(context.getString(R.string.error_saf_write))
                    }
                } else {
                    cleanup(finalTempFile)
                }
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                Log.e(TAG, "Error merging final audiobook: ${exportException.message}")
                cleanup(finalTempFile)
                onError(context.getString(R.string.error_merging))
            }
        })

        Handler(context.mainLooper).post {
            if (!isCancelled) {
                mergeTransformer.start(composition, finalTempFile.absolutePath)
            }
        }
    }

    private fun writeToMediaStore(finalTempFile: File): Boolean {
        Log.i(TAG, "Exporting to MediaStore")
        
        val safeName = bookName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val fileName = "$safeName.m4a"
    
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
            
            // On API 29+, we can cleanly organize this into a subfolder
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Environment.DIRECTORY_AUDIOBOOKS is API 30+
                val magicDir = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Environment.DIRECTORY_AUDIOBOOKS
                } else {
                    // fallback to one of the values that existed on 10,
                    // i.e. one of [Alarms, _Music_, Notifications, Podcasts, Ringtones
                    Environment.DIRECTORY_PODCASTS
                }
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${magicDir}/OpenAudiobookify")
                // Optional: Mark as pending while we write to prevent other apps from reading a partial file
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
    
        val resolver = context.contentResolver
        val audioCollection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
    
        // This creates the file entry in the system database and returns the URI to write to
        val targetUri = resolver.insert(audioCollection, contentValues) ?: return false
    
        return try {
            resolver.openOutputStream(targetUri)?.use { outStream ->
                finalTempFile.inputStream().use { inStream ->
                    inStream.copyTo(outStream)
                }
            }
            
            // If we marked it pending, unmark it now that we are done writing
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(targetUri, contentValues, null, null)
            }

            cleanup(finalTempFile)
            true
        } catch (e: Exception) {
            Log.e(TAG, "MediaStore Write Error: ${e.message}")
            // Cleanup the orphaned MediaStore entry if the write failed
            resolver.delete(targetUri, null, null)
            false
        }
    }

    private fun writeToSaf(finalTempFile: File): Boolean {
        Log.i(TAG, "Exporting to SAF")
        try {
            val tree = DocumentFile.fromTreeUri(context, outputDirUri!!) ?: return false
            val safeName = bookName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            
            // Generate a unique filename by appending (1), (2), etc. if it exists
            var finalName = safeName
            var counter = 1
            while (tree.findFile("$finalName.m4a") != null) {
                finalName = "$safeName ($counter)"
                counter++
            }
            
            val fileName = "$finalName.m4a"

            val docFile = tree.createFile("audio/mp4", fileName) ?: return false
            context.contentResolver.openOutputStream(docFile.uri)?.use { outStream ->
                finalTempFile.inputStream().use { inStream ->
                    inStream.copyTo(outStream)
                }
            } ?: return false
            return true
        } catch (e: Exception) {
            Log.e(TAG, "SAF Write Error during final export: ${e.message}")
            return false
        }
    }

    private fun writeToOutputDir(finalTempFile: File): Boolean {
        if (outputDirUri != null) {
            return writeToSaf(finalTempFile)
        } else {
            return writeToMediaStore(finalTempFile)
        }
    }

    private fun cleanup(finalTempFile: File? = null) {
        Log.i(TAG, "cleanup")
        val wavFile = getWavFile(chunkIndex)
        if (wavFile.exists()) wavFile.delete()

        val tempM4a = getTempM4aFile(chunkIndex)
        if (tempM4a.exists()) tempM4a.delete()

        encodedChunkFiles.forEach { file ->
            if (file.exists()) file.delete()
        }
        encodedChunkFiles.clear()

        context.cacheDir.listFiles()?.forEach { file ->
            if (file.name.startsWith("temp_audiobook_chunk_") || 
                file.name == "final_merged_audiobook.m4a") {
                file.delete()
            }
        }

        if (finalTempFile?.exists() == true) {
            finalTempFile.delete()
        }
    }

    private fun getWavFile(index: Int) = File(context.cacheDir, "temp_audiobook_chunk_$index.wav")
    private fun getEdgeMp3File(index: Int) = File(context.cacheDir, "temp_audiobook_chunk_$index.mp3")
    private fun getTempM4aFile(index: Int) = File(context.cacheDir, "temp_audiobook_chunk_$index.m4a")
}
